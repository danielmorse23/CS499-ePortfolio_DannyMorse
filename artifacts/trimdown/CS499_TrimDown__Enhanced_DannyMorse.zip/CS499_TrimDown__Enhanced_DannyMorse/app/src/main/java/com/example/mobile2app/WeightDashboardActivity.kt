package com.example.mobile2app

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class WeightDashboardActivity : AppCompatActivity() {

    // Stores the logged in user's database ID
    private var userId: Long = -1L

    // Input fields for a new weight entry
    private lateinit var etNewDate: EditText
    private lateinit var etNewWeight: EditText
    private lateinit var etNewNotes: EditText
    private lateinit var btnAddEntry: Button

    // Table used to display saved entries
    private lateinit var tblWeights: TableLayout

    // Repository for DB
    private lateinit var repo: WeightRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weight_dashboard)

        // Reads the user ID
        userId = intent.getLongExtra("USER_ID", -1L)
        if (userId == -1L) {
            Toast.makeText(this, "Invalid login, please try again!", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Connects UI view to code
        etNewDate = findViewById(R.id.etNewDate)
        etNewWeight = findViewById(R.id.etNewWeight)
        etNewNotes = findViewById(R.id.etNewNotes)
        btnAddEntry = findViewById(R.id.btnAddEntry)
        tblWeights = findViewById(R.id.tblWeights)

        // Initializes DB
        repo = WeightRepository(this)

        // Loads any existing entries into the table
        refreshTable()

        // Handles button clicks
        btnAddEntry.setOnClickListener {
            createEntry()
        }
    }

    // Validates input and saves a new weight entry
    private fun createEntry() {
        val date = etNewDate.text.toString().trim()
        val weightText = etNewWeight.text.toString().trim()
        val notes = etNewNotes.text.toString().trim()


        // Enhancement 2: Validates the dates format to ensure it is correct befor saving the input
        if (date.isBlank()) {
            Toast.makeText(this, "Date required!", Toast.LENGTH_SHORT).show()
            return
        }

        val dateParts = date.split("/")

        if (dateParts.size != 3) {
            Toast.makeText(this, "Please use a MM/DD/YYYY format!", Toast.LENGTH_SHORT).show()
            return
        }

        val enteredMonth = dateParts[0].toIntOrNull()
        val enteredDay = dateParts[1].toIntOrNull()
        val enteredYear = dateParts[2].toIntOrNull()

        if (enteredMonth == null || enteredDay == null || enteredYear == null) {
            Toast.makeText(this, "The date may only contain numbers", Toast.LENGTH_SHORT).show()
            return
        }

        if (enteredMonth !in 1..12 ||
            enteredDay !in 1..31 ||
            enteredYear !in 1900..2100
        ) {
            Toast.makeText(this, "Must enter a valid date", Toast.LENGTH_SHORT).show()
            return
        }

        // Enhancement 1: Validates that the user enters a NUMERIC weight before it attempts to save it to the DB
        val weight = weightText.toDoubleOrNull()

        if (weight == null) {
            Toast.makeText(this, "Please enter a valid number value", Toast.LENGTH_SHORT).show()
            return
        }

        // Enhancement 1: Prevents invalid weight values from being put in the DB
        if (weight < 50 || weight > 700) {
            Toast.makeText(
                this,
                "Weight must be between 50 and 700 pounds.",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        // Saves the entry to DB
        repo.add(userId, date, weight, notes)

        Toast.makeText(this, "Entry has been saved!", Toast.LENGTH_SHORT).show()

        // Clears input fields after saving
        etNewDate.text.clear()
        etNewWeight.text.clear()
        etNewNotes.text.clear()

        // Reloads the table so the new entry appears
        refreshTable()
    }

    // Reloads all saved entries into the table
    private fun refreshTable() {
        tblWeights.removeAllViews()

        val entries = repo.readList(userId)

        // Adds a header row to the table
        val header = TableRow(this)
        header.addView(makeCell("Date", true))
        header.addView(makeCell("Weight", true))
        header.addView(makeCell("Notes", true))
        tblWeights.addView(header)

        // Adds one row per database entry
        for (e in entries) {
            val row = TableRow(this)
            row.addView(makeCell(e.date))
            row.addView(makeCell("${e.weight} lbs"))
            row.addView(makeCell(e.notes ?: ""))
            tblWeights.addView(row)
        }
    }

    // Creates a single table cell
    private fun makeCell(text: String, isHeader: Boolean = false): TextView {
        return TextView(this).apply {
            this.text = text
            setPadding(12, 8, 12, 8)
            textSize = if (isHeader) 14f else 13f
        }
    }
}
