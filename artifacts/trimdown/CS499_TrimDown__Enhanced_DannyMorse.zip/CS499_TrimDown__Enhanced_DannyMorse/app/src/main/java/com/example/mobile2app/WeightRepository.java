package com.example.mobile2app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

public class WeightRepository {

    // Handles access to the SQLite database
    private final SQLiteDB db;

    // Initializes
    public WeightRepository(Context context) {
        db = new SQLiteDB(context);
    }

    // Saves a new weight entry for the respective user
    public long add(long userId, String date, double weight, String notes) {
        SQLiteDatabase writableDb = db.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(SQLiteDB.E_USER_ID, userId);
        values.put(SQLiteDB.E_DATE, date.trim());
        values.put(SQLiteDB.E_WEIGHT, weight);
        values.put(SQLiteDB.E_NOTES, notes == null ? "" : notes.trim());

        return writableDb.insert(SQLiteDB.TABLE_ENTRIES, null, values);
    }

    // This returns the weight entries for the respective user
    public Cursor readAll(long userId) {
        SQLiteDatabase readableDb = db.getReadableDatabase();

        return readableDb.query(
                SQLiteDB.TABLE_ENTRIES,
                new String[]{
                        SQLiteDB.U_ID,
                        SQLiteDB.E_DATE,
                        SQLiteDB.E_WEIGHT,
                        SQLiteDB.E_NOTES
                },
                SQLiteDB.E_USER_ID + "=?",
                new String[]{String.valueOf(userId)},
                null,
                null,
                SQLiteDB.U_ID + " DESC"
        );
    }

    // Returns data as a list for the adapter
    public List<WeightEntry> readList(long userId) {
        Cursor c = readAll(userId);
        List<WeightEntry> out = new ArrayList<>();

        try {
            while (c.moveToNext()) {
                long id = c.getLong(c.getColumnIndexOrThrow(SQLiteDB.U_ID));
                String date = c.getString(c.getColumnIndexOrThrow(SQLiteDB.E_DATE));
                double weight = c.getDouble(c.getColumnIndexOrThrow(SQLiteDB.E_WEIGHT));
                String notes = c.getString(c.getColumnIndexOrThrow(SQLiteDB.E_NOTES));

                out.add(new WeightEntry(id, date, weight, notes));
            }
        } finally {
            c.close();
        }

        return out;
    }

    // Enhancement 5: Restricts a user to only editing entries that they create or own
    public int update(long entryId, long userId, String date, double weight, String notes) {
        SQLiteDatabase writableDb = db.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(SQLiteDB.E_DATE, date.trim());
        values.put(SQLiteDB.E_WEIGHT, weight);
        values.put(SQLiteDB.E_NOTES, notes == null ? "" : notes.trim());

        return writableDb.update(
                SQLiteDB.TABLE_ENTRIES,
                values,
                SQLiteDB.U_ID + "=? AND " + SQLiteDB.E_USER_ID + "=?",
                new String[]{
                        String.valueOf(entryId),
                        String.valueOf(userId)
                }
        );
    }

    // Enhancement 5: Restricts deletion to users who own the item they are attempting to delete.
    public int delete(long entryId, long userId) {
        SQLiteDatabase writableDb = db.getWritableDatabase();

        return writableDb.delete(
                SQLiteDB.TABLE_ENTRIES,
                SQLiteDB.U_ID + "=? AND " + SQLiteDB.E_USER_ID + "=?",
                new String[]{
                        String.valueOf(entryId),
                        String.valueOf(userId)
                }
        );
    }
}
