package com.example.mobile2app

import android.content.Intent
import android.database.sqlite.SQLiteConstraintException
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.security.MessageDigest

// Handles new user account creation and collects registration input, validates data, hashes the password, and stores user in DB

class RegistrationActivity : AppCompatActivity() {

    // Repo for user table
    private lateinit var userRepo: UserRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_registration)

        // Initialize database access
        userRepo = UserRepository(this)

        // Input fields
        val etName = findViewById<EditText>(R.id.etFullName)
        val etEmail = findViewById<EditText>(R.id.etRegisterEmail)
        val etPass = findViewById<EditText>(R.id.etRegisterPassword)
        val etConfirm = findViewById<EditText>(R.id.etConfirmPassword)

        // Action buttons
        val btnCreate = findViewById<Button>(R.id.btnFinishRegistration)
        val btnBack = findViewById<Button>(R.id.btnBackToLogin)

        // Returns to prev screen
        btnBack.setOnClickListener {
            finish()
        }

        // Create new user
        btnCreate.setOnClickListener {

            // Reads input values
            val name = etName.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val pass = etPass.text.toString()
            val confirm = etConfirm.text.toString()

            // Input validation
            if (name.isEmpty() || email.isEmpty() || pass.isEmpty() || confirm.isEmpty()) {
                Toast.makeText(this, "Fill out all of the fields please!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            // Enhancement 4: Validate email format before creating an account.
            val emailPattern = android.util.Patterns.EMAIL_ADDRESS

            if (!emailPattern.matcher(email).matches()) {
                Toast.makeText(
                    this,
                    "Must enter a valid email address format",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            // Enhancement 3: Password strength validation
            val hasUppercase = pass.any { it.isUpperCase() }
            val hasLowercase = pass.any { it.isLowerCase() }
            val hasNumber = pass.any { it.isDigit() }

            if (pass.length < 8 || !hasUppercase || !hasLowercase || !hasNumber) {
                Toast.makeText(
                    this,
                    "Password must be at least 8 characters and contain uppercase, lowercase, and a number.",
                    Toast.LENGTH_LONG
                ).show()

                return@setOnClickListener
            }

            // Ensure passwords match
            if (pass != confirm) {
                Toast.makeText(
                    this,
                    "Passwords do not match.",
                    Toast.LENGTH_SHORT
                ).show()

                return@setOnClickListener
            }

            // Hashes the password before storage
            val hash = sha256(pass)

            try {
                // Inserts the new user into the database
                val newId = userRepo.registerUser(name, email, hash)

                // Register fail
                if (newId == -1L) {
                    Toast.makeText(this, "Account could not be created", Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }

                // Register succeeds
                Toast.makeText(this, "Account created successfully", Toast.LENGTH_SHORT).show()

                // Return to login screen
                val intent = Intent(this, MainActivity::class.java)
                intent.putExtra("prefill_email", email)
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)
                startActivity(intent)
                finish()

            } catch (e: SQLiteConstraintException) {
                Toast.makeText(this, "Email already registered", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                // Catches unexpected failures
                Toast.makeText(this, "Registration failed", Toast.LENGTH_SHORT).show()
            }
        }
    }

    //Generates a SHA-256 hash

    private fun sha256(input: String): String {
        val bytes = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
