package com.example.mobile2app;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// Acts as a bridge between the list of WeightEntry objects and the UI. It is also responsible for creating the item views and binding data to them
public class WeightEntryAdapter extends RecyclerView.Adapter<WeightEntryAdapter.VH> {

    public interface OnEntryClick {
        void onTap(WeightEntry entry);   // Triggered on a short press
        void onHold(WeightEntry entry);  // Triggered on a long press
    }

    // List of weight entries to display
    private final List<WeightEntry> items;

    // Callback for user interaction
    private final OnEntryClick callback;

    public WeightEntryAdapter(List<WeightEntry> items, OnEntryClick callback) {
        this.items = items;
        this.callback = callback;
    }

    //Creates a new ViewHolder
    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_entry, parent, false);
        return new VH(v);
    }

    //Binds data from a WeightEntry object to an existing view
    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        WeightEntry e = items.get(position);

        // Populate the row views with entry data
        h.date.setText(e.date);
        h.weight.setText(e.weight + " lbs");
        h.notes.setText(e.notes == null ? "" : e.notes);

        // Handles one tap interaction
        h.itemView.setOnClickListener(v -> callback.onTap(e));

        // Handles long tap
        h.itemView.setOnLongClickListener(v -> {
            callback.onHold(e);
            return true;
        });
    }

    //Returns the total number of items in the list.

    @Override
    public int getItemCount() {
        return items.size();
    }

    //Caches references to the views inside each RecyclerView

    static class VH extends RecyclerView.ViewHolder {

        TextView date;
        TextView weight;
        TextView notes;

        VH(@NonNull View itemView) {
            super(itemView);

            // Connects layout views
            date = itemView.findViewById(R.id.tvItemDate);
            weight = itemView.findViewById(R.id.tvItemWeight);
            notes = itemView.findViewById(R.id.tvItemNotes);
        }
    }
}
