package com.example.mobile2app;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class UserRepository {

    // References the SQ DB
    private final SQLiteDB db;

    // Setting up ability to access the DB
    public UserRepository(Context context) {
        db = new SQLiteDB(context);
    }

    // Adds a new user after registration submission
    public long registerUser(String name, String email, String passwordHash) {
        SQLiteDatabase writableDb = db.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(SQLiteDB.U_FULL_NAME, name.trim());
        values.put(SQLiteDB.U_EMAIL, email.trim().toLowerCase());
        values.put(SQLiteDB.U_PASSWORD_HASH, passwordHash);

        return writableDb.insert(SQLiteDB.TABLE_USERS, null, values);
    }

    // Checks login credentials and returns the user ID if valid
    public long login(String email, String passwordHash) {
        SQLiteDatabase readableDb = db.getReadableDatabase();

        Cursor cursor = readableDb.query(
                SQLiteDB.TABLE_USERS,
                new String[]{ SQLiteDB.U_ID, SQLiteDB.U_PASSWORD_HASH },
                SQLiteDB.U_EMAIL + "=?",
                new String[]{ email.trim().toLowerCase() },
                null, null, null
        );

        try {
            // User wasnt found
            if (!cursor.moveToFirst()) return -1;

            // Wrong password
            if (!cursor.getString(1).equals(passwordHash)) return -1;

            // Successful login
            return cursor.getLong(0);
        } finally {
            cursor.close();
        }
    }
}
