package com.example.mobile2app;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SQLiteDB extends SQLiteOpenHelper {

    private static final String DB_NAME = "trimdown.db";
    private static final int DB_VERSION = 1;

    public static final String TABLE_USERS = "users";
    public static final String TABLE_ENTRIES = "weight_entries";

    public static final String U_ID = "id";
    public static final String U_FULL_NAME = "full_name";
    public static final String U_EMAIL = "email";
    public static final String U_PASSWORD_HASH = "password_hash";

    public static final String E_USER_ID = "user_id";
    public static final String E_DATE = "date";
    public static final String E_WEIGHT = "weight";
    public static final String E_NOTES = "notes";

    // Sets up the DB and the version its on
    public SQLiteDB(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    // Creates the tables once the DB is created
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE " + TABLE_USERS + " (" +
                        U_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        U_FULL_NAME + " TEXT NOT NULL, " +
                        U_EMAIL + " TEXT NOT NULL UNIQUE, " +
                        U_PASSWORD_HASH + " TEXT NOT NULL" +
                        ")"
        );

        db.execSQL(
                "CREATE TABLE " + TABLE_ENTRIES + " (" +
                        U_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        E_USER_ID + " INTEGER NOT NULL, " +
                        E_DATE + " TEXT NOT NULL, " +
                        E_WEIGHT + " REAL NOT NULL, " +
                        E_NOTES + " TEXT, " +
                        "FOREIGN KEY(" + E_USER_ID + ") REFERENCES " +
                        TABLE_USERS + "(" + U_ID + ")" +
                        ")"
        );
    }

    // Will rebuild the tables if the DB version changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ENTRIES);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }
}
