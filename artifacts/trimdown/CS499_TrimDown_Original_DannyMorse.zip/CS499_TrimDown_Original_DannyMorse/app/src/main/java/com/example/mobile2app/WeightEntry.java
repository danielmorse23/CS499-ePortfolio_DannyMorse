package com.example.mobile2app;

// Simple holder
public class WeightEntry {
    public final long id;
    public final String date;
    public final double weight;
    public final String notes;

    public WeightEntry(long id, String date, double weight, String notes) {
        this.id = id;
        this.date = date;
        this.weight = weight;
        this.notes = notes;
    }
}
